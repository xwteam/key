<?php require("header.php");?> 
<div class="bg-image-pattern"></div>
<div align="center">  



<div class="wrapper">
<a href="./download.php"><img src='img/wifipng.png'width='28%'/></a>
<h1 class="STYLE1">1分钟玩转面版</h1>—— WEB面板基本使用向导 ——

</br></br>
<div id="x">
		<input type="button" name="loguser" value="返回首页" class="btn btn-success" onclick="window.location='./';">&nbsp;&nbsp;
		<button onclick="window.location='download.php';" class="btn btn-primary" type="button">下载配置</button>
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
           <div class="input-group">
<font size='6' color='blue'>创建账号</font><br />
<font size='5' color='red'>1、创建OpenVPN账号</font><br />
<font size='4' color='green'>进入web首页，注册会员，被注册的会员账号用于连接OpenVPN的账号密码使用。</font><br /><br />
<font size='5' color='red'>2、激活会员账号</font><br />
<font size='4' color='green'>进入高级管理，“增减流量”选项，为注册的会员添加流量（没有添加流量的账号是无法连接OpenVPN的哦）</font>
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
<font size='6' color='blue'>常见问题</font><br />
<font size='5' color='red'>1、高级管理-生成账号</font><br />
<font size='4' color='green'>请勿使用高级管理功能的“生成账号”，此操作系统会生成N个会员账号，服务器差的会导致宕机。</font><br /><br />
<font size='5' color='red'>2、高级管理-添加流量</font><br />
<font size='4' color='green'>进入高级管理，“增减流量”选项；添加100M流量请输入：+100 ；减少100 MB流量请输入：-100</font><br /><br />
<font size='5' color='red'>3、找回ovpn配置文件</font><br />
<font size='4' color='green'>进入后台主页，点击WIFI图标即可下载配置文件。</font><br /><br />
<font size='5' color='red'>4、无法进去后台</font><br />
<font size='4' color='green'>请在SSH控制台执行：vpn  命令重启服务。</font>
           </div>

           </div>
			
</div>
<?php require("footer.php");?>
