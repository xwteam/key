// JavaScript Document
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  


if(getCookie("du")!=""  &&  getCookie("dp")!=""){
	
	
xmlhttp.open("POST","../php/k.php?dl=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+getCookie("du")+"&p="+getCookie("dp"));
var fh=xmlhttp.responseText; 	
 if(fh=="1"){
	
	alert("参数错误");
	exit();
	
	} if(fh=="2"){
	
	alert("帐号密码错误");
	exit();
	
	}if(fh=="3"){
	
	alert("此帐号未开通代理");
	exit();
	
	}if(fh!=""){
	
	document.getElementById("x").innerHTML=xmlhttp.responseText+"<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='帐号'><span class='input-group-addon'>代理帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='密码'><span class='input-group-addon'>代理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='au'id='au'value=''class='form-control'placeholder='会员'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='流量（MB）'><span class='input-group-addon'>转送流量</span></div><br/>&nbsp<button onclick='dl_z()'class='btn btn-success'type='button'>立即转账</button></div><div>";  
	document.getElementById("u").value=getCookie("du");
	document.getElementById("p").value=getCookie("dp");
	
	exit();
	
	}  
	
	
	
	}










  
  function dl_dl(){
    
var u=document.getElementById("u").value;
var p=document.getElementById("p").value;
if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(p==""){
	
	alert("请输入会员密码");
	exit();
	
	}
	
	
xmlhttp.open("POST","../php/k.php?dl=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+u+"&p="+p);
var fh=xmlhttp.responseText; 	
 if(fh=="1"){
	
	alert("参数错误");
	exit();
	
	} if(fh=="2"){
	
	alert("帐号密码错误");
	exit();
	
	}if(fh=="3"){
	
	alert("此帐号未开通代理");
	exit();
	
	}if(fh!=""){

setCookie("du",u,3600);   
setCookie("dp",p,3600); 
	document.getElementById("x").innerHTML=xmlhttp.responseText+"<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='帐号'><span class='input-group-addon'>代理帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='密码'><span class='input-group-addon'>代理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='au'id='au'value=''class='form-control'placeholder='会员'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='流量(MB)'><span class='input-group-addon'>转送流量</span></div><br/>&nbsp<button onclick='dl_z()'class='btn btn-success'type='button'>立即转账</button></div><div>"; 
document.getElementById("u").value=getCookie("du");
	document.getElementById("p").value=getCookie("dp");
	exit();
	
	}  


}




 function dl_z(){
    
var u=document.getElementById("u").value;
var p=document.getElementById("p").value;
var au=document.getElementById("au").value;
var l=document.getElementById("l").value;

if(u==""){
	
	alert("请输入代理帐号");
	exit();
	
	}if(p==""){
	
	alert("请输入代理密码");
	exit();
	
	}if(au==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入要转送的流量");
	exit();
	
	}
	
xmlhttp.open("POST","../php/k.php?dla=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("u="+u+"&p="+p+"&au="+au+"&l="+l);
var fh=xmlhttp.responseText; 
if(fh=="1"){
	
	alert("帐号密码错误");
	exit();
	
	}if(fh=="2"){
	
	alert("此帐号未成为代理");
	exit();
	
	}if(fh=="3"){
	
	alert("流量不足");
	exit();
	
	}if(fh=="4"){
	
	alert("会员增加流量失败");
	exit();
	
	} if(fh=="5"){
	
	alert("转流量失败");
	exit();
	
	}if(fh=="6"){
	
	alert("转流量成功");
	exit();
	
	}if(fh=="7"){
	
	alert("无法减少流量");
	exit();
	
	}      	
	
	
	}
	
	
	
	function getCookie(c_name)
{
if (document.cookie.length>0)
  {
  c_start=document.cookie.indexOf(c_name + "=")
  if (c_start!=-1)
    { 
    c_start=c_start + c_name.length+1 
    c_end=document.cookie.indexOf(";",c_start)
    if (c_end==-1) c_end=document.cookie.length
    return unescape(document.cookie.substring(c_start,c_end))
    } 
  }
return ""
}

function setCookie(c_name,value,expiredays)
{
var exdate=new Date()
exdate.setDate(exdate.getDate()+expiredays)
document.cookie=c_name+ "=" +escape(value)+
((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
}

function checkCookie()
{
username=getCookie('username')
if (username!=null && username!="")
  {alert('Welcome again '+username+'!')}
else 
  {
  username=prompt('Please enter your name:',"")
  if (username!=null && username!="")
    {
    setCookie('username',username,365)
    }
  }
}	 	