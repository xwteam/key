</div align="center">

<div>

  <div align="center" class="STYLE2">Copyright ©<?php echo date("Y")?> 云流量平台 All Rights Reserved.</div>
</div>


<!-- Javascript -->

<script src="js/supersized.3.2.7.min.js"></script>
<script src="js/supersized-init.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>