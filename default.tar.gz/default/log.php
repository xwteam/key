<?php require("header.php");?> 
<div class="bg-image-pattern"></div>
<div align="center">  



<div class="wrapper">
<a href="./download.php"><img src='img/wifipng.png'width='28%'/></a>
<h1 class="STYLE1">在线用户</h1>—— <?php doAction('tips_top'); ?> ——

</br></br>
<div id="x">
		<input type="button" name="loguser" value="返回首页" class="btn btn-success" onclick="window.location='./';">&nbsp;&nbsp;
		<input type="button" name="loguser" value="页面刷新" class="btn btn-info" onclick="window.location='./log.php';">
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
           <div class="input-group">
<?php
header("Content-type: text/html; charset=UTF-8"); $name; $ip; $sent=0; $recv=0; $str=file_get_contents("./res/openvpn-status.txt"); $num=(substr_count($str,'2016')-1)/2; $fp=fopen("./res/openvpn-status.txt","r"); fgets($fp); fgets($fp); fgets($fp); for($i=0;$i!=$num;$i++){ $line=fgets($fp); $arr=explode(",",$line); $recv=ceil($arr[2]/1024)/1000; $sent=ceil($arr[3]/1024)/1000; echo "用户名:[&nbsp;<font color='blue'> ".$arr[0]."</font>&nbsp;]"; echo "&nbsp;&nbsp;IP地址:[&nbsp;<font color='green'>".$arr[1]."</font>&nbsp;]<br />"; echo "上传:[&nbsp;<font color='red'>".$recv."&nbsp;MB</font>&nbsp;]"; echo "&nbsp;&nbsp;下载:[&nbsp;<font color='red'>".$sent."&nbsp;MB</font>&nbsp;]<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'> "; } ?>
           </div>

           </div>
			
</div>
<?php require("footer.php");?>
