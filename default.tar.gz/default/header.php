<?PHP include("php/V1.php");
?>
<?php require_once('function.base.php'); ?> 
<?php include("tips.php"); ?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">



<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>云流量平台</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">


<!-- CSS -->

<link rel="stylesheet" href="css/supersized.css">
<link rel="stylesheet" href="css/login.css">
<link href="css/zui.css" rel="stylesheet" type="text/css" />
<link href="css/zui.lite.css" rel="stylesheet" type="text/css" />
<link href="css/zui.lite.min.css" rel="stylesheet" type="text/css" />
<link href="css/zui.min.css" rel="stylesheet" type="text/css" />
<link href="css/zui-theme.css" rel="stylesheet" type="text/css" />
<link href="css/zui-theme.min.css" rel="stylesheet" type="text/css" />
<link href="css/css.css" rel="stylesheet" type="text/css" />
<link rel="icon" type="image/x-icon" href="img/favicon.ico">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
<script src="js/zui.min.js"></script>
<script src="js/doc.min.js"></script>
<script src="js/jquery.js"></script>

<?php

    $phpself=php_self();
 if($phpself == 'admin.php'){
echo '<script src="js/admin.js"></script>';
}
else{
echo '<script src="js/a.js"></script>';
}
?>


<style type="text/css">
<!--
.STYLE1 {color: #000;font-family: "Microsoft YaHei","微软雅黑","Trebuchet MS",Arial,Verdana,Tahoma,sans-serif;}
.STYLE2 {color: #FFF}
-->
img{
    -webkit-transition: 0.4s;
    -webkit-transition: -webkit-transform 0.4s ease-out;
    transition: transform 0.4s ease-out;
    -moz-transition: -moz-transform 0.4s ease-out;
}
  
img:hover{
    transform: rotateZ(360deg);
    -webkit-transform: rotateZ(360deg);
    -moz-transform: rotateZ(360deg);
}
</style>


<script src="js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/tooltips.js"></script>
</head>
<body>