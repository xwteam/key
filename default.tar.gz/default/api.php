<div align="center">
  <form id="form1" name="form1" method="get" action="">
    <label>
    <input name="u" type="text" id="u" />
    </label>
    <label>
    <input type="submit" name="Submit" value="go" />
    </label>
  </form>
  </div>
<?php


include("php/conn.php");
$_COOKIE['D']=$D;
$_COOKIE['E']=$E;
if($_GET['u']!=""){
    
    
    
     $U=trim($_GET['u']);
     ECHO(C($U));
     
     
}



function C($U){
    
 $U=trim($U);  
  IF($U==""){
    
  return "1";  //����������
    
 }   
  
  $SQL="SELECT * 
FROM  `openvpn` 
WHERE  `iuser` LIKE  '$U'
LIMIT 0 , 30";
$FH=mysql_query($SQL);
$SJ=mysql_fetch_array($FH);

IF($SJ['iuser']==$U){


    
    $SJ['isent']=$SJ['isent']/1024/1024;
    $SJ['irecv']=$SJ['irecv']/1024/1024;
    $SJ['maxll']=$SJ['maxll']/1024/1024;
    
    
    
    
     $SJ['isent']=floor($SJ['isent']);
      $SJ['irecv']=floor($SJ['irecv']);
       $SJ['maxll']=floor($SJ['maxll']);
    
    
    
    
    $SSS=strtotime($SJ['rq']);
    $SSSA=strtotime($SJ['starttime']);
    $RQQ=$SSS-time();
    $RQQ=$RQQ/60/60/24;
    $RQQ=floor($RQQ);
    $aaa=$SJ['maxll']-$SJ['irecv']-$SJ['isent'];   
  if($SJ['i']=="1"){
    $SJ['T']="正常"   ; 
        
    }if($SJ['i']=="0"){
    $SJ['T']="停用"   ;
        
    }
 $BC="
 
 
 <table  class=\"table table-bordered\">
  <tr>
    <td>会员帐号：</td>
    <td>".$SJ['iuser']."</td>
  </tr>
  <tr>
    <td>会员状态：</td>
    <td>".$SJ['T']."</td>
  </tr>
  <tr>
    <td>已经上传：</td>
    <td>".$SJ['isent']."M</td>
  </tr>
  <tr>
    <td>已经下载：</td>
    <td>".$SJ['irecv']."M</td>
  </tr>
  <tr>
    <td>总共流量：</td>
    <td>".$SJ['maxll']."M</td>
  </tr>
  <tr>
    <td>剩余流量：</td>
    <td>".$aaa."M</td>
  </tr>
  <tr>
    <td>开通时间：</td>
    <td>".$SJ['starttime']."</td>
  </tr>
  <tr>
   <tr>
    <td>到期时间：</td>
    <td>".$SJ['rq']."</td>
  </tr>
  <tr>
    <td>剩余时间：</td>
    <td>". $RQQ."天</td>
  </tr>

</table>
 
 

 ";
 
$BC= iconv("UTF-8","GBK",$BC);
 
 return $BC;

    
}return "2";  //


    
    
}

?>