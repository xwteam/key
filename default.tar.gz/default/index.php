<?php require("header.php");?> 
<div class="bg-image-pattern"></div>
<div align="center">  


<div class="wrapper">
<a href="./download.php"><img src='img/wifipng.png'width='28%'/></a>
<h1 class="STYLE1">[注册/登录] 帐号</h1>—— <?php doAction('tips_top'); ?> ——

</br></br>
<div id="x">


           <div class="input-group">
             <span class="input-group-addon"><i class="icon icon-user"></i></span>
             <input type="text" name="u" id="u" value="" class="form-control" placeholder="帐号">
             <span class="input-group-addon">会员帐号</span>
           </div>
			<BR/>
			
			<div class="input-group">
             <span class="input-group-addon"><i class="icon icon-eye-open"></i></span>
             <input type="password" name="p" id="p" value="" class="form-control" placeholder="密码">
             <span class="input-group-addon">会员密码</span>
           </div>
        
		<br/>
		<button onclick="bba()" class="btn btn-success" type="button">登陆账号</button>
		<button onclick="zc_a()" class="btn btn-primary" type="button">注册账号</button>
		<input type="button" name="Submit" value="代理登录" class="btn btn-info" onclick="window.location='dl.php';"><br/><br/>
		<input type="button" name="Submit" value="高级管理" class="btn btn-info" onclick="window.location='admin.php';">
		<input type="button" name="loguser" value="在线用户" class="btn btn-info" onclick="window.location='log.php';">
		<input type="button" name="loguser" value="使用教程" class="btn btn-info" onclick="window.location='info.php';">
           </div>
			
</div>
<?php require("footer.php");?> 