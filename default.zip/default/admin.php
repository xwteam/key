<?php require("header.php");?> 
<div class="bg-image-pattern"></div>
<div align="center">  



<div class="wrapper">
<a href="./download.php"><img src='img/wifipng.png'width='28%'/></a>
<h1 class="STYLE1">高级管理</h1>—— <?php doAction('tips_top'); ?> ——

</br></br>
<div id="x">



		<button onclick="a()" class="btn btn-block btn-primary" type="button">增减流量</button>
		<br/>
		<button onclick="b()" class="btn btn-block btn-info" type="button">冻结帐号</button>
		 <br/>
		<button onclick="c();" class="btn  btn-block btn-success" type="button">删除帐号</button>
		 <br/>
		<button onclick="d();" class="btn btn-block btn-warning" type="button">修改密码</button>
		<br/>
		<button onclick="e();" class="btn btn-block btn-danger" type="button">会员列表</button>
		<br/>
		 <button onclick="f()" class="btn btn-block btn-primary" type="button">生成帐号</button>
		 <br/>
		 <button onclick='dl()'class='btn btn-block btn-success'type='button'>设置代理</button>
         <br/>
		<button onclick="g()" class="btn btn-block btn-info" type="button">找回密码</button>
		<br/>
		<button onclick="xg()" class="btn btn-block btn-warning" type="button">增减天数</button>

		<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
		<input type="button" name="loguser" value="返回首页" class="btn btn-success" onclick="window.location='./';">
</div>
<?php require("footer.php");?>