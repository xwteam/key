<?php

include("php/conn.php");
$S=date('Y-m-d',time());


$SQL="SELECT * 
FROM  `openvpn` 
WHERE  `rq` LIKE  '$S'
LIMIT 0 , 30";
$FH=mysql_query($SQL);
while($SJ=mysql_fetch_array($FH)){
    
    $SQL="DELETE FROM `openvpn` WHERE `openvpn`.`id` = ".$SJ['id']." LIMIT 1";
    if(mysql_query($SQL)){
        
        ECHO("S-OK<br/>");
        
    }
  
    
    
}




?>