<?php require("header.php");?> 
<div class="bg-image-pattern"></div>
<div align="center">  



<div class="wrapper">
<img src='img/wifipng.png'width='28%'/>
<h1 class="STYLE1">OpenVPN配置下载</h1>—— 请根据自己的手机运营商选择配置 ——

</br></br>
<div id="x">
		<input type="button" name="loguser" value="返回首页" class="btn btn-success" onclick="window.location='./';">
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
           
<font size='4' color='blue'>移动配置下载</font><br /><br />
<button onclick="javascript:window.location.href='/download/cmcc/OpenVPN-HTTP.ovpn'" class="btn btn-block btn-primary" type="button">HTTP转接</button><br />
<button onclick="javascript:window.location.href='/download/cmcc/OpenVPN-Old.ovpn'" class="btn btn-block btn-primary" type="button">常规配置</button><br />
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
<font size='4' color='red'>联通配置下载</font><br /><br />
<button onclick="javascript:window.location.href='/download/cucc/OpenVPN-HTTP.ovpn'" class="btn btn-block btn-primary" type="button">HTTP转接</button><br />
<button onclick="javascript:window.location.href='/download/cucc/OpenVPN-Old.ovpn'" class="btn btn-block btn-primary" type="button">常规配置</button><br />
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
<font size='4' color='green'>电信配置下载</font><br /><br />
<button onclick="alert('很抱歉，我们暂时不支持电信！')" class="btn btn-block btn-primary" type="button">HTTP转接</button><br />
<button onclick="alert('很抱歉，我们暂时不支持电信！')" class="btn btn-block btn-primary" type="button">常规配置</button><br />
<hr width=80% size=3 color=#00ffff style='filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)'>
         

           </div>
			
</div>
<?php require("footer.php");?>
