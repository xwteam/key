// JavaScript Document


var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
 
 
 
  function a(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-cloud'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='流量增减（MB）'><span class='input-group-addon'>流量增减</span></div><BR/><button onclick='admin_a();'class='btn btn-block btn-warning'type='button'>确定添加</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	   document.getElementById("admin").value=getCookie("admin");
	  
	  }
	  
	  
	  
  function xg(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-cloud'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='增减天数'><span class='input-group-addon'>增减天数</span></div><BR/><button onclick='admin_xg();'class='btn btn-block btn-warning'type='button'>确定修改</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	  
	  
	  
	  
	  
	  
	  
	  
  function b(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><select class='form-control btn-block'name='t' id='t'><option value='1'>选择-恢复正常</option><option value='2'>选择-冻结帐号</option><option value='3'>选择-帐号重置</option></select></div><BR/><button onclick='admin_b();'class='btn btn-block btn-warning'type='button'>确定修改</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回菜单</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	 
	  
	  
	  function c(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><button onclick='admin_c();'class='btn btn-block btn-warning'type='button'>确定删除</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	   
	  
	  
	  
	  
	 	  function d(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='旧管理密码'><span class='input-group-addon'>旧管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='u'id='u'value=''class='form-control'placeholder='新管理密码'><span class='input-group-addon'>新管理密码</span></div><BR/><button onclick='admin_d();'class='btn btn-block btn-warning'type='button'>确定修改</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	 
	  
	  
		 	  function f(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='账号数量'><span class='input-group-addon'>帐号数量</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='流量数量（MB）'><span class='input-group-addon'>流量数量</span></div><br/><div id='ok'></div><br/><button onclick='admin_f()'class='btn btn-block btn-info'type='button'>立即生成</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	   
	  
	  
	  
	  
	  function g(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><br/><div id='ok'></div><br/><button onclick='admin_g()'class='btn btn-block btn-info'type='button'>立即找回</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	 
	  
	  
	  
	  
	  
 function dl(){
	  
	  document.getElementById("x").innerHTML="<div class='input-group'><span class='input-group-addon'><i class='icon icon-user'></i></span><input type='text'name='admin'id='admin'value=''class='form-control'placeholder='管理密码'><span class='input-group-addon'>管理密码</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='p'id='p'value=''class='form-control'placeholder='会员帐号'><span class='input-group-addon'>会员帐号</span></div><BR/><div class='input-group'><span class='input-group-addon'><i class='icon icon-eye-open'></i></span><input type='text'name='l'id='l'value=''class='form-control'placeholder='1代表设置代理0代表取消代理'><span class='input-group-addon'>代理设置</span></div><br/><div id='ok'></div><br/><button onclick='admin_dl()'class='btn btn-block btn-info'type='button'>立即修改</button><br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  }	   	  
	  
	  
	  
	  
	   function fh(){
	  
	  document.getElementById("x").innerHTML="<button onclick='a()'class='btn btn-block btn-primary'type='button'>增减流量</button><br/><button onclick='b()'class='btn btn-block btn-info'type='button'>冻结帐号</button><br/><button onclick='c();'class='btn  btn-block btn-success'type='button'>删除帐号</button><br/><button onclick='d();'class='btn btn-block btn-warning'type='button'>修改密码</button><br/><button onclick='e();'class='btn btn-block btn-danger'type='button'>会员列表</button><br/><button onclick='f()'class='btn btn-block btn-primary'type='button'>生成帐号</button><br/><button onclick='g()'class='btn btn-block btn-info'type='button'>找回密码</button><br/><button onclick='dl()'class='btn btn-block btn-success'type='button'>设置代理</button><br/><button onclick='xg();'class='btn btn-block btn-warning'type='button'>增减天数</button><hr width=80% size=3 color=#00ffff style=\'filter:progid:DXImageTransform.Microsoft.Shadow(color:#f6ae56,direction:145,strength:15)\'><input type=\"button\" name=\"loguser\" value=\"返回首页\" class=\"btn btn-success\" onclick=\"window.location=\'admin.php\';\">";
	  document.getElementById("admin").value=getCookie("admin");
	  
	  } 
	  
	  
	  
 
  
 function admin_a(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;
var l=document.getElementById("l").value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入流量数/MB");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?c=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&l="+l);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("帐号不存在");
	exit();
	
	} if(fh=="2"){
	
	alert("操作失败");
	exit();
	
	}if(fh=="3"){
	setCookie("admin",admin,3600);
	alert("操作成功");
	exit();
	
	}if(fh=="4"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 
	 


 function admin_xg(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;
var l=document.getElementById("l").value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入天数");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?ts=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&l="+l);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("帐号不存在");
	exit();
	
	} if(fh=="2"){
	
	alert("操作失败");
	exit();
	
	}if(fh=="3"){
	
	alert("操作成功");
	setCookie("admin",admin,3600);
	exit();
	
	}if(fh=="4"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 


	 
 function admin_b(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;
var objSel = document.getElementById("t");
var t=objSel.value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}if(t==""){
	
	alert("请选择状态");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?d=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&t="+t);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("修改失败");
	exit();
	
	} if(fh=="4"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh=="3"){
	setCookie("admin",admin,3600);
	alert("修改成功");
	exit();
	
	}if(fh=="5"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 	 
	 


function admin_c(){
	 
	 
	var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;


if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?e=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("修改失败");
	exit();
	
	} if(fh=="4"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh=="3"){
	setCookie("admin",admin,3600);
	alert("删除成功");
	exit();
	
	}if(fh=="5"){
	
	alert("管理密码错误");
	exit();
	
	}
	 
	 
	 } 	 
	 
	
	 
function admin_d(){
	 
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("u").value;


if(admin==""){
	
	alert("请输入旧管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入新管理密码");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?f=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("修改失败");
	exit();
	
	}if(fh=="3"){
	setCookie("admin",admin,3600);
	alert("修改成功");
	exit();
	
	}
	 
	 
	 } 
	 
	 
	 
 function e(){
	 
	 
xmlhttp.open("GET","../php/hy.php",false);
xmlhttp.send();
var fh=xmlhttp.responseText; 	 
 document.getElementById("x").innerHTML=fh+"<br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";	 
	 }	 
	 
	 
 function e_a(id){
	 
	 
xmlhttp.open("GET","../php/hy.php?page="+id,false);
xmlhttp.send();
var fh=xmlhttp.responseText; 	 
 document.getElementById("x").innerHTML=fh+"<br/><button onclick='fh()'class='btn btn-block btn-primary'type='button'>返回主页</button>";	 
	 }	 
	 
	 
	 
function admin_f(){
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("p").value;
var l=document.getElementById("l").value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入需要生成的账号数量");
	exit();
	
	}if(l==""){
	
	alert("请输入需要生成的账号流量");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?g=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&l="+l);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("生成失败");
	exit();
	
	}if(fh.indexOf("帐号")>0){
	 document.getElementById("ok").innerHTML=fh;
	 setCookie("admin",admin,3600);
	alert("生成成功");
	exit();
	
	}
	 
	 
	 } 
 	 
	 
function admin_g(){
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("p").value;


if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("请输入会员帐号");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?k=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh.indexOf("|")>0){
	 document.getElementById("ok").innerHTML=fh;	
	 setCookie("admin",admin,3600);
	alert("找回成功");
	exit();
	
	}
	 
	 
	 } 

	 
function admin_dl(){
	 
var admin=document.getElementById("admin").value;
var u=document.getElementById("p").value;
var l=document.getElementById("l").value;

if(admin==""){
	
	alert("请输入管理密码");
	exit();
	
	}if(u==""){
	
	alert("会员帐号");
	exit();
	
	}if(l==""){
	
	alert("请输入设置1代表设置代理0代表取消代理");
	exit();
	
	}
	
	
	xmlhttp.open("POST","../php/k.php?dlq=ok",false);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("admin="+admin+"&u="+u+"&l="+l);
var fh=xmlhttp.responseText; 

 if(fh=="1"){
	
	alert("管理密码错误");
	exit();
	
	} if(fh=="2"){
	
	alert("帐号不存在");
	exit();
	
	}if(fh=="3"){
		setCookie("admin",admin,3600);
	alert("修改成功");
	exit();
	
	}if(fh=="4"){
	alert("修改失败");
	exit();
	
	}
	 
	 
	 } 	 
	 
		 
	function getCookie(c_name)
{
if (document.cookie.length>0)
  {
  c_start=document.cookie.indexOf(c_name + "=")
  if (c_start!=-1)
    { 
    c_start=c_start + c_name.length+1 
    c_end=document.cookie.indexOf(";",c_start)
    if (c_end==-1) c_end=document.cookie.length
    return unescape(document.cookie.substring(c_start,c_end))
    } 
  }
return ""
}

function setCookie(c_name,value,expiredays)
{
var exdate=new Date()
exdate.setDate(exdate.getDate()+expiredays)
document.cookie=c_name+ "=" +escape(value)+
((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
}

function checkCookie()
{
username=getCookie('username')
if (username!=null && username!="")
  {alert('Welcome again '+username+'!')}
else 
  {
  username=prompt('Please enter your name:',"")
  if (username!=null && username!="")
    {
    setCookie('username',username,365)
    }
  }
}	 