<?php require("header.php");?> 
<div class="bg-image-pattern"></div>
<div align="center">  

<img class="bg-image" src="../img/bj.jpg"> 

<div class="wrapper">
<a href="./download.php"><img src='img/wifipng.png'width='28%'/></a>
<h1 class="STYLE1">云流量代理</h1>—— <?php doAction('tips_top'); ?> ——
</br></br>
<div id="x">


           <div class="input-group">
             <span class="input-group-addon"><i class="icon icon-user"></i></span>
             <input type="text" name="u" id="u" value="" class="form-control" placeholder="帐号">
             <span class="input-group-addon">代理帐号</span>
           </div>
			<BR/>
			
			<div class="input-group">
             <span class="input-group-addon"><i class="icon icon-eye-open"></i></span>
             <input type="password" name="p" id="p" value="" class="form-control" placeholder="密码">
             <span class="input-group-addon">代理密码</span>
           </div>
        
		<br/>
		
		<button onclick="dl_dl()" class="btn btn-success" type="button">立即登录</button>&nbsp;&nbsp;
		<input type="button" name="loguser" value="返回首页" class="btn btn-primary" onclick="window.location='./';">

</div>

</div>
<script src="../js/dl.js"></script>
<?php require("footer.php");?> 
